class Particle(object):
    """A particle is a constituent unit of the universe."""

    hear_me = "I am a particle!"

    def roar(self):
        print Particle.hear_me

