import numpy

from particles.particle import Particle

class ElementaryParticle(Particle):
    """ElementaryParticle has the following attributes:

    - s          - the spin of the ElementaryParticle
    - is_fermion (boolean)  
    - is_boson   (boolean)
    """
    def __init__(self, spin):
        Particle.__init__(self)
        self.s = spin
        self.is_fermion = bool(spin%1.0)
        self.is_boson = not self.is_fermion
        self.constituents = None
