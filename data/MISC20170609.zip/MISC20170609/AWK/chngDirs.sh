ls -d EXPT* | while read dir
do
  echo mv $dir `echo $dir | awk -F"EXPT" '{printf("EXPT%03d \n",$2)}'`
done
