for i in `seq 1 12`
do
  echo $i
  mkdir EXPT$i
  temp=`echo $i | awk -v t=$i '{print t/10+1}'`
  echo $temp
  cat > EXPT$i/run_parameters.dat <<!
Temperature: $temp
!
done
