int isum(int num_numbers, int *numbers){
// Add up an array of num_numbers integers 
    int i;
    int sum=0;
    for (i=0; i<num_numbers; i++){
        sum+=numbers[i];
    }
    return sum;
}
