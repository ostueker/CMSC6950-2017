import ctypes

_sum = ctypes.CDLL('libsum.so') 

_sum.isum.argtypes = (ctypes.c_int, ctypes.POINTER(ctypes.c_int))

def sum_ints(list_of_ints):
    global _sum
    num_numbers = len(list_of_ints)
    array_type = ctypes.c_int * num_numbers
    result = _sum.isum(ctypes.c_int(num_numbers), array_type(*list_of_ints))
    return int(result)

ilist=[1,2,3,10,100]

print(sum_ints(ilist))
