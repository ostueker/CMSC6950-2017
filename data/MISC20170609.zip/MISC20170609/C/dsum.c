double dsum(int num_numbers, double *numbers){
// Add up an array of num_numbers double precision numbers
    int i;
    double sum=0.;
    for (i=0; i<num_numbers; i++){
        sum+=numbers[i];
    }
    return sum;
}
