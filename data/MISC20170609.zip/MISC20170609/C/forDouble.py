import ctypes

_sum = ctypes.CDLL('libsum.so')

_sum.dsum.argtypes = (ctypes.c_int, ctypes.POINTER(ctypes.c_double))

def sum_doubles(list_of_doubles):
    global _sum  #this helps the python interpreter find our library
    num_numbers = len(list_of_doubles)
    array_type = ctypes.c_double * num_numbers
    result = _sum.dsum(ctypes.c_int(num_numbers), array_type(*list_of_doubles))
    return result

doublelist=[1.,2.,3.]

print( sum_doubles(doublelist))
